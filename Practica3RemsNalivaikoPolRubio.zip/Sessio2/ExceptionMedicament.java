package Sessio2;

public class ExceptionMedicament extends Exception {
    public ExceptionMedicament(){super();}
    public ExceptionMedicament(String msg){super(msg);}
}
